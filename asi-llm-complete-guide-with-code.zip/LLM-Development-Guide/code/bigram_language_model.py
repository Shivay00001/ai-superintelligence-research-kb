
import re
from collections import defaultdict, Counter

class BigramLanguageModel:
    def __init__(self):
        self.bigram_counts = defaultdict(Counter)
        self.unigram_counts = Counter()

    def preprocess(self, text):
        text = text.lower()
        tokens = re.findall(r'\b\w+\b', text)
        return tokens

    def train(self, text):
        tokens = self.preprocess(text)
        tokens = ['<s>'] + tokens + ['</s>']
        for i in range(len(tokens) - 1):
            self.unigram_counts[tokens[i]] += 1
            self.bigram_counts[tokens[i]][tokens[i + 1]] += 1

    def probability(self, word, previous):
        if previous in self.bigram_counts and word in self.bigram_counts[previous]:
            return self.bigram_counts[previous][word] / self.unigram_counts[previous]
        else:
            return 0.0
